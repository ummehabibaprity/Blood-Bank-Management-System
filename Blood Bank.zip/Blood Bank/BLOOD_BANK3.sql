CREATE TABLE CUSTOMER
(
CustomerId int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,

Address varchar(200) NULL,
Phone varchar(11) NULL,
)




CREATE TABLE BLOODBANK
(
BankNo int IDENTITY(1,1) PRIMARY KEY,
Blood_type varchar(50) NOT NULL,
Orders int Not Null,
issues Date not null

)

CREATE TABLE ORDERS
(
OrderId int IDENTITY(1,1) PRIMARY KEY,
Orderdate date not null,
Blood_type varchar(50) not null,

BankNo int not null  FOREIGN KEY REFERENCES BLOODBANK (BankNo),
CustomerId  int not null  FOREIGN KEY REFERENCES CUSTOMER(CustomerId ),

)


CREATE TABLE MANAGER
(
ManagerId int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,

EmailId varchar(50) NULL,
Phone varchar(11) NULL,
BankNo int not null FOREIGN KEY REFERENCES BLOODBANK (BankNo),
)

CREATE TABLE RECEPTIONIST
(
ReceptionistId int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,

Address varchar(200) NULL,
Phone varchar(11) NULL,
BankNo int not null FOREIGN KEY REFERENCES BLOODBANK (BankNo),
)

CREATE TABLE DONOR
(
DonorId int IDENTITY(1,1) PRIMARY KEY,
Name varchar(50) NOT NULL,
Sex varchar(50) NOT NULL,
Age varchar(50) NOT NULL,
Address varchar(200) NULL,
Phone varchar(11) NULL,

ReceptionistId int not null  FOREIGN KEY REFERENCES  RECEPTIONIST (ReceptionistId),
)

CREATE TABLE BLOOD
(
BloodCode int IDENTITY(1,1) PRIMARY KEY,
Blood_type varchar(50) not null,
Cost int not null,
DonorId int not null FOREIGN KEY REFERENCES DONOR(DonorId),
BankNo int not null FOREIGN KEY REFERENCES BLOODBANK (BankNo),

)



Insert into CUSTOMER(Name,Address,Phone) values
('karim','Gulsahn','01784343453'),
 ('Rahman',  'Dhanmondi', '01912584949'),
       ('Mehedi',  'Gulshan', '01645789544'),
('kader','mohakhali','01784343452'),
 ('Rahim',  'Dhanmondi', '01912584942'),
       ('Miraz',  'Gulshan', '01645789543')


Insert into BLOODBANK(Blood_Type,Orders,issues) values('A+','1','2018-2-18'),
('AB+','17','2011-12-18'),
('B+','21','2010-2-18'),
('AB+','10','2018-2-18'),
('B+','7','2011-12-18'),
('AB+','21','2010-2-18')





Insert into ORDERS(Orderdate,Blood_type,BankNo,CustomerId) values('2018-2-18','A+','1','2'),('2011-2-18','B+','3','3'),('2010-2-18','AB+','2','1')


Insert into MANAGER(Name,EmailId,Phone,BankNo) values ('Abdur','abdur@gmail.com','01984343453','1'),
 ('Rakes',  'rakes@yahoo.com', '01812584949','2'),
       ('Mubarak',  'mubarak@gmail.com', '01545789544','3')

Insert into RECEPTIONIST(Name,Address,Phone,BankNo) values
('kader','Banani','01784343453','1'),
 ('Raha',  'Dhanmondi', '01912584949','1'),
    ('Maruf',  'khilgaon', '01645789544','2'),	
('karim','Banani','01784343451','1'),
 ('Rames',  'Dhanmondi', '01912584943','2'),
    ('Mamun',  'khilgaon', '01645789543','2')

	
Insert into DONOR(Name,Sex,Age,Address,Phone,ReceptionistId) values
('Ambani','male','32','Banani','01784343453','1'),
 ('pinky', 'female','42', 'Dhanmondi', '01912584949','1'),
    ('Mahatab','male','38',  'khilgaon', '01645789544','2'),
('Akash','male','22','Banani','01784343452','1'),
 ('proma', 'female','12', 'Dhanmondi', '01912584940','3'),
    ('Mahbub','male','38',  'khilgaon', '01645789545','2')

Insert into BLOOD(Blood_type,Cost,DonorId,BankNo) values('AB+','400','2','2'),('B+','600','3','3'),('A+','400','1','1'),('O+','400','6','1'),('AB+','400','4','2'),('B+','600','3','3'),('A+','400','5','1')
	
-->
select*from BLOOD
select* from DONOR
select*from RECEPTIONIST
select* from MANAGER
select*from ORDERS
select* from BLOODBANK
-->
update ORDERS set BankNo='2' where CustomerId='2'
update RECEPTIONIST set Address='Rampura' where Name='Raha'
Delete from BLOOD where Blood_type='O+'


-->
ALTER TABLE CUSTOMER ADD Blood_type varchar
ALTER TABLE CUSTOMER DROP COLUMN Blood_type
-->
select *from RECEPTIONIST order by Address,Name desc
select *from CUSTOMER order by Phone
select distinct Address from RECEPTIONIST
select distinct Blood_type from BLOOD
-->
select *from CUSTOMER where CustomerId='4'
select *from RECEPTIONIST where BankNo='2'
select *from BLOOD where Blood_type='AB+'
select *from Donor where ReceptionistId='2'
select Orderdate,Blood_type,BankNo from ORDERS where CustomerId='2'
select Blood_type,ORDERS from BLOODBANK where issues='2018-02-18'
select distinct Blood_type from BLOOD where Cost>='400'


-->
select *from CUSTOMER where Phone like '017%'
select*from DONOR Where Address like 'B%'
select*from DONOR Where Name like 'M%b'
-->
select *from DONOR where Age in (32,42)
select *from CUSTOMER where CustomerId in (2,5)
select *from DONOR where Age between 12 and 42
select distinct Blood_type,Cost from BLOOD where Cost between  200 and 700
select *from DONOR where Age>=12 and Sex='female'
SELECT * FROM DONOR WHERE NAME LIKE 'K%' AND (AGE >= 20 OR Address ='Banani') 
select top 70 percent *from DONOR 
select top 3  *from CUSTOMER
--> 
select count(CustomerId)from CUSTOMER
select max(Cost)from BLOOD
select min(Cost)from BLOOD
select sum(cost)from BLOOD
select avg(cost)from BLOOD
select len(Name)from DONOR where DonorId='2'
select Upper(Name)from CUSTOMER where CustomerId='4'
select lower(Name)from DONOR where DonorId='6'
-->
select COUNT(ReceptionistId),BankNo from RECEPTIONIST group by BankNo
select COUNT(ManagerId),BankNo from MANAGER group by BankNo
select max(cost) ,Blood_type from BLOOD group by Blood_type
select sum(Orders),Blood_type from BLOODBANK group by Blood_type
select count(DonorId)as Total_Donor,ReceptionistId from DONOR group by ReceptionistId 
select count(DonorId)as Donor,Age from DONOR group by Age having Age>=15 
select sum(Orders)as Total_Orders,Blood_type from BLOODBANK group by Blood_type having Blood_type='AB+'
select count(DonorId)as Donor,BankNo from BLOOD Group By BankNo having BankNo=2
-->
select Customer.Name,Address,Phone,ORDERS.Blood_type,Orderdate,BankNo from CUSTOMER,ORDERS where CUSTOMER.CustomerId=ORDERS.CustomerId
select DONOR.Name,Age,Sex,Address,BLOOD.Blood_type,BankNo from DONOR,BLOOD where BLOOD.DonorId=DONOR.DonorId

Project was done as part of a training programme

use mysql to create the database. the table names are given in query/createTable.txt file

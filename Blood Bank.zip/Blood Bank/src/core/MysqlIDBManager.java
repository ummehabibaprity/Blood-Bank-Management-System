/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author DELL
 */
public interface MysqlIDBManager {

    static final String DBURL = "jdbc:mysql://localhost:3306/bloodbank";
    //static Connection con=null;
    static final String DBDRIVER = "com.mysql.jdbc.Driver";
    static final String USER = "root";
    static final String PASS = "password";
}
